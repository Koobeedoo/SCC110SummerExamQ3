public class FootballField
{
    public static final int PITCH_LENGTH = 800;
    public static final int PITCH_WIDTH = 400;
    public static final int BOX_LENGTH = 100;
    public static final int BOX_WIDTH = 200;
    
    private GameArena window;
    private Person[] people;
    private Person selectedPerson;
    private Text infoText;
    
    public FootballField()
    {
        window = new GameArena(PITCH_LENGTH + 200, PITCH_WIDTH + 150);
        this.drawPitch();
        this.addPeople();
        this.addData();
        this.play();
    }

    private void addData()
    {
        infoText = new Text("", 20, 25, 25, "YELLOW", 1);
        window.addText(infoText);
    }

    private void addPeople()
    {
        String names = {"Kelly Widdicks", "Joe Finney", "Nigel Davies", "Paul Dempster", "Bran Knowles" };
        people = new Person[5];

        for(int i=0; i<names.length; i++){
            people[i] = new Person(names[i], 500+i*50 , 75);
            window.addBall(people[i].getBall());
        }
    }

    private void drawPitch()
    {
        Rectangle grass = new Rectangle(0,50, PITCH_LENGTH+200, PITCH_WIDTH+100, "GREEN");
        Line[] pitchMarking = {
            new Line(100,100, 100+PITCH_LENGTH, 100, 3, "WHITE", 1),
            new Line(100+PITCH_LENGTH, 100, 100+PITCH_LENGTH, 100+PITCH_WIDTH, 3, "WHITE", 1),
            new Line(100,100, 100, 100+PITCH_WIDTH, 3, "WHITE", 1),
            new Line(100,100+PITCH_WIDTH, 100+PITCH_LENGTH, 100+PITCH_WIDTH, 3, "WHITE", 1),
            new Line(100+PITCH_LENGTH/2,100, 100+PITCH_LENGTH/2, 100+PITCH_WIDTH, 3, "WHITE", 1),

            new Line(100,100+PITCH_WIDTH/2-BOX_WIDTH/2, 100+BOX_LENGTH, 100+PITCH_WIDTH/2-BOX_WIDTH/2, 3, "WHITE", 1),
            new Line(100,100+PITCH_WIDTH/2+BOX_WIDTH/2, 100+BOX_LENGTH, 100+PITCH_WIDTH/2+BOX_WIDTH/2, 3, "WHITE", 1),
            new Line(100+BOX_LENGTH,100+PITCH_WIDTH/2-BOX_WIDTH/2, 100+BOX_LENGTH, 100+PITCH_WIDTH/2+BOX_WIDTH/2, 3, "WHITE", 1),

            new Line(100+PITCH_LENGTH-BOX_LENGTH,100+PITCH_WIDTH/2-BOX_WIDTH/2, 100+PITCH_LENGTH, 100+PITCH_WIDTH/2-BOX_WIDTH/2, 3, "WHITE", 1),
            new Line(100+PITCH_LENGTH-BOX_LENGTH,100+PITCH_WIDTH/2+BOX_WIDTH/2, 100+PITCH_LENGTH, 100+PITCH_WIDTH/2+BOX_WIDTH/2, 3, "WHITE", 1),
            new Line(100+PITCH_LENGTH-BOX_LENGTH,100+PITCH_WIDTH/2-BOX_WIDTH/2, 100+PITCH_LENGTH-BOX_LENGTH, 100+PITCH_WIDTH/2+BOX_WIDTH/2, 3, "WHITE", 1),
        };

        window.addRectangle(grass);

        for (int i=0; i<pitchMarking.length; i++)
            window.addLine(pitchMarking[i]);
        }
    }   

    public void play()
    {
        Ball b = new Ball(0,0, 1, "RED");

        while(true)
        {
            if (window.leftMousePressed())
            {
                if(selectedPerson == null)
                {
                    b.setXPosition(window.getMousePositionX());
                    b.setYPosition(window.getMousePositionY());

                    for (int i=0; i<people.length; i++)
                    {
                        if (people[i].getBall().collides(b))
                        {
                            selectedPerson = people[i];
                        }
                    }
                }
                else
                {
                    selectedPerson.getBall().setXPosition(b.getXPosition());
                    selectedPerson.getBall().setYPosition(b.getYPosition());    
                }
            }
            else
            {
                selectedPerson = null;
            }

            window.pause();
        }
    }

    public static void main(String[] args)
    {
        FootballField f = new FootballField();
    }
}