public class Person
{
    private Ball image;
    private String name;

    public Person(String personName, int x, int y)
    {
        name = personName;
        image = new Ball(x, y, 25, "BLUE");
    }

    public Ball getBall()
    {
        return image;
    }
}